import { Component, OnInit } from '@angular/core';
import { ForgotpwdComponent } from '../forgotpwd/forgotpwd.component';
import { RouterLink, RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-hospital-login',
  standalone: true,
  imports: [ForgotpwdComponent,RouterLink,RouterOutlet,CommonModule,ReactiveFormsModule],
  templateUrl: './hospital-login.component.html',
  styleUrl: './hospital-login.component.css'
})
export class HospitalLoginComponent implements OnInit {
loginform!:FormGroup;
constructor(private fb:FormBuilder){

}
ngOnInit(): void {
  this.loginform=this.fb.group({
    userRole:['',[Validators.required]],
    identifier: ['', [Validators.required, this.validateIdentifier]],
    password: ['',[Validators.required, Validators.minLength(8),
        Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$')
      ]
    ]
  })
}
validateIdentifier(control: any) {
  const value = control.value;
  if (!value) return { invalid: true };

  // Regular expressions for validation
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;       // Matches email format
  const usernamePattern = /^[a-zA-Z0-9_]{4,}$/;           // Matches username (at least 4 characters)
  const registerIdPattern = /^[a-zA-Z0-9]{6,12}$/;        // Matches alphanumeric Register ID (6-12 characters)

  if (emailPattern.test(value) || usernamePattern.test(value) || registerIdPattern.test(value)) {
    return null; // Valid input
  }

  return { invalid: true }; // Invalid input
}
}
