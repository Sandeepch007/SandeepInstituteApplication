import { Component } from '@angular/core';

@Component({
  selector: 'app-adminusers',
  standalone: true,
  imports: [],
  templateUrl: './adminusers.component.html',
  styleUrl: './adminusers.component.css'
})
export class AdminusersComponent {

}
