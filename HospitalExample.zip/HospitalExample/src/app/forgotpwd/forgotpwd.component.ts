import { Component } from '@angular/core';

@Component({
  selector: 'app-forgotpwd',
  standalone: true,
  imports: [],
  templateUrl: './forgotpwd.component.html',
  styleUrl: './forgotpwd.component.css'
})
export class ForgotpwdComponent {

}
