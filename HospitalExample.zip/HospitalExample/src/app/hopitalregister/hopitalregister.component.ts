import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-hopitalregister',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './hopitalregister.component.html',
  styleUrl: './hopitalregister.component.css'
})
export class HopitalregisterComponent {

}
