import { Component } from '@angular/core';

@Component({
  selector: 'app-doctorpatients',
  standalone: true,
  imports: [],
  templateUrl: './doctorpatients.component.html',
  styleUrl: './doctorpatients.component.css'
})
export class DoctorpatientsComponent {

}
