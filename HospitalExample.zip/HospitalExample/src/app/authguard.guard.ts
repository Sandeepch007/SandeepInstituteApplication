import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';


export const authguardGuard: CanActivateFn = () => {
  const router=inject(Router);
  const role=localStorage.getItem('userRole');
  if(role==='admin' && router.url.startsWith('/admin')){
    return true;
  }
  else if(role==='doctor' && router.url.startsWith('/doctor')){
    return true;
  }
  else if(role==='patient' && router.url.startsWith('/patient')){
    return true;
  }
  else{
    router.navigate(['/login']);
    return false;
  }
};
