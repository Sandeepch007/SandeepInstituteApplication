import { Component } from '@angular/core';

@Component({
  selector: 'app-hospital-home',
  standalone: true,
  imports: [],
  templateUrl: './hospital-home.component.html',
  styleUrl: './hospital-home.component.css'
})
export class HospitalHomeComponent {

}
