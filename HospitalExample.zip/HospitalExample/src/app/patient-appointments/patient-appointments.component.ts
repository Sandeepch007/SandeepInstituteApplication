import { Component } from '@angular/core';

@Component({
  selector: 'app-patient-appointments',
  standalone: true,
  imports: [],
  templateUrl: './patient-appointments.component.html',
  styleUrl: './patient-appointments.component.css'
})
export class PatientAppointmentsComponent {

}
