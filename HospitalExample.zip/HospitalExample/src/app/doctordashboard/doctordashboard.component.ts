import { Component } from '@angular/core';

@Component({
  selector: 'app-doctordashboard',
  standalone: true,
  imports: [],
  templateUrl: './doctordashboard.component.html',
  styleUrl: './doctordashboard.component.css'
})
export class DoctordashboardComponent {

}
