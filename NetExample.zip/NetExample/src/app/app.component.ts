import { Component, OnInit, OnDestroy, Inject, PLATFORM_ID } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { AgGridModule } from 'ag-grid-angular';
import { ColDef } from 'ag-grid-community';
import { SampleService } from './sample.service';
import { ModuleRegistry, AllCommunityModule } from 'ag-grid-community';
import {
  ClientSideRowModelModule,
  AdvancedFilterModule,
  ColumnMenuModule,
  ContextMenuModule,
  ExcelExportModule,
  RowGroupingModule,
  RowGroupingPanelModule,
  SetFilterModule,
} from 'ag-grid-enterprise';

// Register the AG Grid modules
ModuleRegistry.registerModules([
  AllCommunityModule,
  ClientSideRowModelModule,
  AdvancedFilterModule,
  ColumnMenuModule,
  ContextMenuModule,
  ExcelExportModule,
  RowGroupingModule,
  RowGroupingPanelModule,
  SetFilterModule,
]);

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, AgGridModule], // Import AG Grid module
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit, OnDestroy {
  forexData: any[] = [];
  columnDefs: ColDef[] = [];
  private dataInterval: any;
  isBrowser: boolean = false;

  constructor(@Inject(PLATFORM_ID) private platformId: object, private samp: SampleService) {
    this.isBrowser = isPlatformBrowser(this.platformId);
  }

  ngOnInit(): void {
    if (this.isBrowser) {
      // Fetch initial data when the component is initialized
      this.fetchInitialData();
      
      // Define column definitions for the grid
      this.columnDefs  = [
        { field: 'symbol', headerName: 'Symbol', sortable: true, filter: true },
        
        // Bid Price with conditional color
        { 
          field: 'bid', 
          headerName: 'Bid Price', 
          sortable: true, 
          filter: true,
          cellStyle: (params) => {
            if (params.value > 100) {
              return { color: 'green', backgroundColor: '#d4f8d4',borderRadius: '30%',  // Circular shape
                padding: '1px 3px' ,  }; // Green text and light green background
            } else if (params.value < 1) {
              return { color: 'red', backgroundColor: '#f8d4d4',borderRadius: '30%',  // Circular shape
                padding: '1px 3px' ,  }; // Red text and light red background
            }
            return null;
          }
          
        },
        
        // Ask Price with conditional color
        { 
          field: 'ask', 
          headerName: 'Ask Price', 
          sortable: true, 
          filter: true,
          cellStyle: (params) => {
            if (params.value > 100) {
              return { color: 'green', backgroundColor: '#d4f8d4',borderRadius: '30%',  // Circular shape
                padding: '1px 3px' ,  }; // Green text and light green background
            } else if (params.value < 1) {
              return { color: 'red', backgroundColor: '#f8d4d4',borderRadius: '30%',  // Circular shape
                padding: '1px 3px' ,  }; // Red text and light red background
            }
            return null;
          }
        },
      
        // Change Price with conditional color
        { 
          field: 'change', 
          headerName: 'Change Price', 
          sortable: true, 
          filter: true,
          cellStyle: (params) => {
            if (params.value > 100) {
              return { color: 'green', backgroundColor: '#d4f8d4',borderRadius: '30%',  // Circular shape
                padding: '1px 3px' ,  }; // Green text and light green background
            } else if (params.value < 1) {
              return { color: 'red', backgroundColor: '#f8d4d4',borderRadius: '30%',  // Circular shape
                padding: '1px 3px' ,  }; // Red text and light red background
            }
            return null;
          
          }
          
        },
      
        { field: 'time', headerName: 'Time', sortable: true }
      ];
      
    }
  }

  

  fetchInitialData() {
    this.forexData = this.samp.getdata(); // Store static data for AG Grid
    this.startDataUpdate(); // Start updating data once initial data is fetched
  }

  startDataUpdate() {
    if (this.isBrowser) {
      this.dataInterval = setInterval(() => {
        this.updateData();
      }, 5000); // Update data every 5 seconds
    }
  }

  updateData() {
    this.forexData = this.forexData.map((data) => ({
      ...data,
      bid: +(data.bid + Math.random() * 0.01).toFixed(2),
      ask: +(data.ask + Math.random() * 0.01).toFixed(2),
      change: +(Math.random() * 2 - 1.5).toFixed(2),
      percentChange: +(Math.random() * 2 - 1.5).toFixed(2),
      time: new Date().toLocaleTimeString(),
    }));
  }

  ngOnDestroy(): void {
    if (this.isBrowser) {
      // Cleanup interval when component is destroyed
      clearInterval(this.dataInterval);
    }
  }
}
