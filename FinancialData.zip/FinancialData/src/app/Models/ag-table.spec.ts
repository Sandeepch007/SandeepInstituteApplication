import { AgTable } from './ag-table';

describe('AgTable', () => {
  it('should create an instance', () => {
    expect(new AgTable()).toBeTruthy();
  });
});
