import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BarChartCellRendererComponent } from './bar-chart-cell-renderer.component';

describe('BarChartCellRendererComponent', () => {
  let component: BarChartCellRendererComponent;
  let fixture: ComponentFixture<BarChartCellRendererComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BarChartCellRendererComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(BarChartCellRendererComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
