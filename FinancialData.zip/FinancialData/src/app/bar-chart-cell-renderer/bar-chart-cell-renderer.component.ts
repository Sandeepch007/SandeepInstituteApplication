import { Component, ElementRef, ViewChild } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { Chart } from 'chart.js/auto';

@Component({
  selector: 'app-bar-chart-cell',
  template: `<canvas #chartCanvas></canvas>`,
  styles: [`canvas { width: 100px; height: 50px; }`]
})
export class BarChartCellRendererComponent implements ICellRendererAngularComp {
  @ViewChild('chartCanvas', { static: true }) chartCanvas!: ElementRef;
  chart: Chart | null = null;

  agInit(params: any): void {
    this.createChart(params.value || []);
  }

  createChart(data: number[]) {
    if (this.chart) {
      this.chart.destroy();
    }
    
    this.chart = new Chart(this.chartCanvas.nativeElement, {
      type: 'bar',
      data: {
        labels: data.map((_, i) => `T${i + 1}`),
        datasets: [{ data, backgroundColor: 'blue' }]
      },
      options: { responsive: false, plugins: { legend: { display: false } } }
    });
  }

  refresh(params: any): boolean {
    this.createChart(params.value || []);
    return true;
  }
}
