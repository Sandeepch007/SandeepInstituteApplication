import { CommonModule, isPlatformBrowser } from '@angular/common';
import { Component, Inject, PLATFORM_ID } from '@angular/core';
import { SampleService } from '../sample.service';
import { AgTable } from '../Models/ag-table';
import { ColDef, GridOptions } from 'ag-grid-community';
import { AgGridAngular, AgGridModule } from 'ag-grid-angular'; 
import { AllCommunityModule, ModuleRegistry } from 'ag-grid-community'; 
import {
  
  ClientSideRowModelModule,
 
 
 
  type ValueFormatterFunc,
  type ValueGetterParams,
} from 'ag-grid-community';


import {
  AdvancedFilterModule,
  CellSelectionModule,
  ColumnMenuModule,
  ColumnsToolPanelModule,
  ContextMenuModule,
  ExcelExportModule,
  FiltersToolPanelModule,
  IntegratedChartsModule,
  RichSelectModule,
  RowGroupingModule,
  RowGroupingPanelModule,
  SetFilterModule,
  SparklinesModule,
  StatusBarModule,
} from 'ag-grid-enterprise';
import { AgChartsEnterpriseModule } from 'ag-charts-enterprise';


// Register all Community features
ModuleRegistry.registerModules([AllCommunityModule,ClientSideRowModelModule,
  AdvancedFilterModule,
  ColumnsToolPanelModule,
  ExcelExportModule,
  FiltersToolPanelModule,
  ColumnMenuModule,
  ContextMenuModule,
  CellSelectionModule,
  RowGroupingModule,
  RowGroupingPanelModule,
  SetFilterModule,
  RichSelectModule,
  StatusBarModule,
  IntegratedChartsModule.with(AgChartsEnterpriseModule),
  SparklinesModule.with(AgChartsEnterpriseModule),
]);
const numberFormatter: ValueFormatterFunc = (params) => {
  const formatter = new Intl.NumberFormat('en-US', {
    style: 'decimal',
    maximumFractionDigits: 2,
  });
  return params.value == null ? '' : formatter.format(params.value);
};

@Component({
  selector: 'app-aggrid-view',
  standalone: true,
  imports: [AgGridAngular, CommonModule,AgGridModule,],
  templateUrl: './aggrid-view.component.html',
  styleUrl: './aggrid-view.component.css'
})
export class AggridViewComponent {
 tables:AgTable[]=[];
 cellSelection: boolean = true;
  enableCharts: boolean = true;
  rowGroupPanelShow: 'always' | 'onlyWhenGrouping' | 'never' | undefined =
    'always';
  suppressAggFuncInHeader: boolean = true;
  groupDefaultExpanded = -1;

  defaultColDef: ColDef = {
    flex: 1,
    filter: true,
    enableRowGroup: true,
    enableValue: true,
  };
  coldefs: ColDef<AgTable>[]=[
      { field: 'name', headerName: 'Name', width: 100 },
      { field: 'instrument', headerName: 'Instrument', width: 100 },
      {
        field: 'purchaseDate',
        headerName: 'Purchase Date',
        width: 150,
        valueFormatter: ({ value }) => value ? new Date(value).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : ''
      },
      
      
      { field: 'purchasePrice', headerName: 'PurchasePrice', width: 100 },
      { field: 'currentPrice', headerName: 'CurrentPrice', width: 150 },
      { field: 'quantity', headerName: 'Quantity', width: 150 },
      {
        field: 'timelineprice',
        headerName: 'TimeLinePrice',
        sortable: false,
      filter: false,
      cellRenderer: 'agSparklineCellRenderer',
      cellRendererParams: {
        sparklineOptions: {
          type: 'bar',
          direction: 'vertical',
          axis: {
            strokeWidth: 0,
          },
          
        },
      },
      },


      {
        colId: 'p&l',
        headerName: 'P&L',
        cellDataType: 'number',
        filter: 'agNumberColumnFilter',
        type: 'rightAligned',
        cellRenderer: 'agAnimateShowChangeCellRenderer',
        valueGetter: ({ data }: ValueGetterParams) => this.calculateValues(data, 'p&l'),
        valueFormatter: numberFormatter,
        aggFunc: 'sum',
        minWidth: 140,
        initialWidth: 140,
      },
      {
        colId: 'totalValue',
        headerName: 'Total Value',
        type: 'rightAligned',
        cellDataType: 'number',
        filter: 'agNumberColumnFilter',
        valueGetter: ({ data }: ValueGetterParams) => this.calculateValues(data, 'totalValue'),
        cellRenderer: 'agAnimateShowChangeCellRenderer',
        valueFormatter: numberFormatter,
        aggFunc: 'sum',
        minWidth: 160,
        initialWidth: 160,
      },
      
  ];

  calculateValues(rowData: any, type: 'p&l' | 'totalValue'): number {
    if (!rowData) return 0; // Ensure row data exists
  
    const quantity = rowData.quantity ?? 1; // Default to 1 if missing
    const price = rowData.currentPrice ?? 0;
    const purchasePrice = rowData.purchasePrice && rowData.purchasePrice !== 0 ? rowData.purchasePrice : 1; // Avoid division by 0
  
    console.log(`Calculating ${type}: Quantity=${quantity}, Price=${price}, PurchasePrice=${purchasePrice}`);
  
    if (type === 'p&l') {
      return quantity * (price / purchasePrice);
    } else if (type === 'totalValue') {
      return quantity * price;
    }
  
    return 0;
  }
  
  
  
  

  isBrowser: boolean;
  AgGridModule: any;

  constructor(@Inject(PLATFORM_ID) private platformId: object,private samp:SampleService) {
    this.isBrowser = isPlatformBrowser(this.platformId);
  }

  

  async ngOnInit(): Promise<void> {
    
    if (this.isBrowser) {
      const { AgGridAngular } = await import('ag-grid-angular');
      this.AgGridModule = AgGridAngular;
    }

    
    this.samp.gettable().subscribe((data:any) => {  
      this.tables = data;
    
    });
  }

  
}








